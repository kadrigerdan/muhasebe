/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.2.2-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: muhasebe
-- ------------------------------------------------------
-- Server version	12.2.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `alis_fatura_detaylari`
--

DROP TABLE IF EXISTS `alis_fatura_detaylari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alis_fatura_detaylari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fatura_id` int(11) NOT NULL,
  `urun_id` int(11) NOT NULL,
  `miktar` int(11) NOT NULL DEFAULT 0,
  `birim_fiyat` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_alis_detay_fatura` (`fatura_id`),
  KEY `idx_alis_detay_urun` (`urun_id`),
  CONSTRAINT `fk_alis_detay_fatura` FOREIGN KEY (`fatura_id`) REFERENCES `alis_faturalar` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_alis_detay_urun` FOREIGN KEY (`urun_id`) REFERENCES `urunler` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alis_fatura_detaylari`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alis_fatura_detaylari` WRITE;
/*!40000 ALTER TABLE `alis_fatura_detaylari` DISABLE KEYS */;
INSERT INTO `alis_fatura_detaylari` VALUES
(1,1,1,40,200.00),
(2,1,4,12,200.00),
(3,1,2,30,10.00),
(4,1,5,15,500.00),
(5,2,15,1,50.00);
/*!40000 ALTER TABLE `alis_fatura_detaylari` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `alis_faturalar`
--

DROP TABLE IF EXISTS `alis_faturalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alis_faturalar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cari_id` int(11) NOT NULL,
  `tarih` date NOT NULL,
  `odenen_tutar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `durum` enum('odenmedi','kismi','odendi') NOT NULL DEFAULT 'odenmedi',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_alis_cari` (`cari_id`),
  CONSTRAINT `fk_alis_cari` FOREIGN KEY (`cari_id`) REFERENCES `cariler` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alis_faturalar`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alis_faturalar` WRITE;
/*!40000 ALTER TABLE `alis_faturalar` DISABLE KEYS */;
INSERT INTO `alis_faturalar` VALUES
(1,1,'2026-09-30',18200.00,'odendi','2026-09-30 16:43:25'),
(2,1,'2026-10-03',50.00,'odendi','2026-10-03 19:20:57');
/*!40000 ALTER TABLE `alis_faturalar` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cariler`
--

DROP TABLE IF EXISTS `cariler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cariler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unvan` varchar(255) DEFAULT NULL,
  `tip` enum('tedarikci','musteri','her_ikisi') NOT NULL DEFAULT 'her_ikisi',
  `telefon` varchar(20) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `vergi_no` varchar(20) DEFAULT NULL,
  `vergi_dairesi` varchar(100) DEFAULT NULL,
  `yetkili` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_unvan` (`unvan`),
  KEY `idx_tip` (`tip`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cariler`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cariler` WRITE;
/*!40000 ALTER TABLE `cariler` DISABLE KEYS */;
INSERT INTO `cariler` VALUES
(1,'Ergaz San.Ltd.Şti.','her_ikisi','0 555 580 6677','Kemalpaşa V.D Ulucak beldesi.Kemalpaşa/İzmir',NULL,NULL,NULL,NULL,1,'2026-09-27 16:44:38'),
(2,'kerem','musteri','05551115588','Akıncılar mh.',NULL,NULL,NULL,NULL,1,'2026-09-02 14:24:13'),
(3,'İkram','musteri','05558844445','dinçer',NULL,NULL,NULL,NULL,1,'2026-09-02 14:25:25'),
(4,'Metin','musteri','05557775544','1.Anafartalar mh.',NULL,NULL,NULL,NULL,1,'2026-09-02 14:28:12'),
(5,'Serdar','musteri','05551213311','Peker mh.',NULL,NULL,NULL,NULL,1,'2026-09-03 16:22:45');
/*!40000 ALTER TABLE `cariler` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fatura_odemeleri`
--

DROP TABLE IF EXISTS `fatura_odemeleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fatura_odemeleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fatura_tipi` enum('alis','satis') NOT NULL,
  `fatura_id` int(11) NOT NULL,
  `tutar` decimal(12,2) NOT NULL,
  `tarih` date NOT NULL,
  `aciklama` varchar(255) DEFAULT NULL,
  `kasadan_dus` tinyint(1) NOT NULL DEFAULT 0,
  `kasa_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fatura` (`fatura_tipi`,`fatura_id`),
  KEY `idx_kasa` (`kasa_id`,`kasadan_dus`),
  KEY `idx_tarih` (`tarih`),
  CONSTRAINT `fk_fo_kasa` FOREIGN KEY (`kasa_id`) REFERENCES `kasa_hesaplari` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fatura_odemeleri`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fatura_odemeleri` WRITE;
/*!40000 ALTER TABLE `fatura_odemeleri` DISABLE KEYS */;
INSERT INTO `fatura_odemeleri` VALUES
(1,'alis',1,18200.00,'2026-10-03',NULL,0,NULL,'2026-10-03 16:33:17'),
(2,'alis',2,50.00,'2026-10-03',NULL,1,1,'2026-10-03 19:22:19'),
(3,'satis',61,140.00,'2026-10-03',NULL,1,1,'2026-10-03 20:13:28'),
(4,'satis',62,220.00,'2026-10-03',NULL,1,1,'2026-10-03 21:24:22'),
(5,'satis',64,700.00,'2026-10-04',NULL,1,1,'2026-10-04 10:24:23'),
(6,'satis',65,76.50,'2026-10-05',NULL,1,1,'2026-10-05 13:02:05'),
(7,'satis',63,280.00,'2026-10-05',NULL,1,1,'2026-10-05 13:30:05'),
(8,'satis',60,250.00,'2026-10-05',NULL,1,1,'2026-10-05 13:30:28'),
(9,'satis',59,30.00,'2026-10-05',NULL,1,1,'2026-10-05 13:30:41'),
(10,'satis',58,290.00,'2026-10-05',NULL,1,1,'2026-10-05 13:30:53'),
(11,'satis',57,580.00,'2026-10-05',NULL,1,1,'2026-10-05 13:31:11'),
(12,'satis',56,300.00,'2026-10-05',NULL,1,1,'2026-10-05 13:31:27'),
(13,'satis',55,6.00,'2026-10-05',NULL,1,1,'2026-10-05 13:31:38'),
(14,'satis',54,580.00,'2026-10-05',NULL,1,1,'2026-10-05 13:31:55'),
(15,'satis',53,100.00,'2026-10-05',NULL,1,1,'2026-10-05 13:32:26'),
(16,'satis',51,400.00,'2026-10-05',NULL,1,1,'2026-10-05 13:33:07'),
(17,'satis',50,153.00,'2026-10-05',NULL,1,1,'2026-10-05 13:33:53'),
(18,'satis',52,3.00,'2026-10-05',NULL,1,1,'2026-10-05 13:34:11'),
(19,'satis',49,50.00,'2026-10-05',NULL,1,2,'2026-10-05 13:34:35'),
(20,'satis',48,37.00,'2026-10-05',NULL,1,2,'2026-10-05 13:34:46'),
(21,'satis',47,70.00,'2026-10-05',NULL,1,2,'2026-10-05 13:34:58'),
(22,'satis',46,150.00,'2026-10-05',NULL,1,1,'2026-10-05 13:35:14'),
(23,'satis',45,30.00,'2026-10-05',NULL,1,2,'2026-10-05 13:35:33'),
(24,'satis',44,300.00,'2026-10-05',NULL,1,2,'2026-10-05 13:36:02'),
(25,'satis',41,70.00,'2026-10-05',NULL,1,2,'2026-10-05 13:36:30'),
(26,'satis',43,150.00,'2026-10-05',NULL,1,2,'2026-10-05 13:36:47'),
(27,'satis',42,220.00,'2026-10-05',NULL,1,1,'2026-10-05 13:36:59'),
(28,'satis',66,70.00,'2026-10-05',NULL,1,1,'2026-10-05 14:03:56');
/*!40000 ALTER TABLE `fatura_odemeleri` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Temporary table structure for view `kasa_bakiye_view`
--

DROP TABLE IF EXISTS `kasa_bakiye_view`;
/*!50001 DROP VIEW IF EXISTS `kasa_bakiye_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `kasa_bakiye_view` AS SELECT
 1 AS `id`,
  1 AS `ad`,
  1 AS `tip`,
  1 AS `banka_adi`,
  1 AS `iban`,
  1 AS `acilis_bakiye`,
  1 AS `aktif`,
  1 AS `created_at`,
  1 AS `bakiye` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `kasa_hareketleri`
--

DROP TABLE IF EXISTS `kasa_hareketleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kasa_hareketleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kasa_id` int(11) NOT NULL,
  `tip` enum('giris','cikis') NOT NULL,
  `tutar` decimal(12,2) NOT NULL,
  `tarih` date NOT NULL,
  `aciklama` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_kasa` (`kasa_id`),
  KEY `idx_tarih` (`tarih`),
  CONSTRAINT `fk_kasa_hareket_kasa` FOREIGN KEY (`kasa_id`) REFERENCES `kasa_hesaplari` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kasa_hareketleri`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kasa_hareketleri` WRITE;
/*!40000 ALTER TABLE `kasa_hareketleri` DISABLE KEYS */;
INSERT INTO `kasa_hareketleri` VALUES
(1,1,'giris',500000.00,'2026-10-01',NULL,'2026-10-01 22:20:05'),
(7,1,'giris',35000.00,'2026-10-03','Elden','2026-10-03 19:14:19'),
(8,1,'cikis',1010.00,'2026-10-04','Masraf','2026-10-04 10:25:26'),
(9,1,'cikis',85000.00,'2026-10-04','Virman → Ziraat Bankası','2026-10-04 14:01:34'),
(10,2,'giris',85000.00,'2026-10-04','Virman ← Merkez Nakit','2026-10-04 14:01:34');
/*!40000 ALTER TABLE `kasa_hareketleri` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kasa_hesaplari`
--

DROP TABLE IF EXISTS `kasa_hesaplari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kasa_hesaplari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(100) NOT NULL,
  `tip` enum('nakit','banka','pos') NOT NULL DEFAULT 'nakit',
  `banka_adi` varchar(100) DEFAULT NULL,
  `iban` varchar(34) DEFAULT NULL,
  `acilis_bakiye` decimal(12,2) NOT NULL DEFAULT 0.00,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_kasa_ad` (`ad`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kasa_hesaplari`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kasa_hesaplari` WRITE;
/*!40000 ALTER TABLE `kasa_hesaplari` DISABLE KEYS */;
INSERT INTO `kasa_hesaplari` VALUES
(1,'Merkez Nakit','nakit',NULL,NULL,0.00,1,'2026-10-01 18:06:19'),
(2,'Ziraat Bankası','banka',NULL,NULL,0.00,1,'2026-10-04 14:01:08');
/*!40000 ALTER TABLE `kasa_hesaplari` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `musteriler_old`
--

DROP TABLE IF EXISTS `musteriler_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `musteriler_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unvan` varchar(255) NOT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `musteriler_old`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `musteriler_old` WRITE;
/*!40000 ALTER TABLE `musteriler_old` DISABLE KEYS */;
INSERT INTO `musteriler_old` VALUES
(6,'kerem','05551115588','Akıncılar mh.','2026-09-02 14:24:13'),
(7,'İkram','05558844445','dinçer','2026-09-02 14:25:25'),
(8,'Metin','05557775544','1.Anafartalar mh.','2026-09-02 14:28:12'),
(9,'Serdar','05551213311','Peker mh.','2026-09-03 16:22:45');
/*!40000 ALTER TABLE `musteriler_old` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `personel`
--

DROP TABLE IF EXISTS `personel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(100) NOT NULL,
  `soyad` varchar(100) NOT NULL,
  `tc_kimlik` varchar(11) DEFAULT NULL,
  `sgk_no` varchar(20) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `dogum_tarihi` date DEFAULT NULL,
  `egitim_durumu` enum('ilkokul','ortaokul','lise','onlisans','lisans','yuksek_lisans','doktora') DEFAULT NULL,
  `ehliyet_sinifi` varchar(10) DEFAULT NULL,
  `ehliyet_tarihi` date DEFAULT NULL,
  `ise_giris_tarihi` date NOT NULL,
  `isten_cikis_tarihi` date DEFAULT NULL,
  `gorev` varchar(100) DEFAULT NULL,
  `departman` varchar(100) DEFAULT NULL,
  `maas` decimal(12,2) NOT NULL DEFAULT 0.00,
  `banka_adi` varchar(100) DEFAULT NULL,
  `iban` varchar(34) DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `notlar` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tc` (`tc_kimlik`),
  KEY `idx_aktif` (`aktif`),
  KEY `idx_departman` (`departman`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personel`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `personel` WRITE;
/*!40000 ALTER TABLE `personel` DISABLE KEYS */;
INSERT INTO `personel` VALUES
(1,'Cemil','Neşeligil','51212365456','1321303',NULL,NULL,NULL,'2026-10-23',NULL,NULL,NULL,'2026-10-13',NULL,NULL,NULL,50000.00,NULL,NULL,1,NULL,'2026-10-01 11:19:39'),
(2,'İsmail','Güllü',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-30',NULL,NULL,NULL,60000.00,NULL,NULL,1,NULL,'2026-10-01 22:03:11'),
(3,'Semih','Balcı',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-30',NULL,NULL,NULL,40000.00,NULL,NULL,1,NULL,'2026-10-01 22:49:29');
/*!40000 ALTER TABLE `personel` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `personel_odeme`
--

DROP TABLE IF EXISTS `personel_odeme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personel_odeme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `odeme_tipi` enum('maas','avans','prim','ikramiye','kesinti','diger') NOT NULL DEFAULT 'maas',
  `tutar` decimal(12,2) NOT NULL,
  `tarih` date NOT NULL,
  `donem` varchar(7) DEFAULT NULL,
  `aciklama` varchar(255) DEFAULT NULL,
  `kasadan_dus` tinyint(1) NOT NULL DEFAULT 0,
  `kasa_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_personel` (`personel_id`),
  KEY `idx_tarih` (`tarih`),
  KEY `idx_donem` (`donem`),
  KEY `idx_po_kasa` (`kasa_id`,`kasadan_dus`),
  CONSTRAINT `fk_odeme_personel` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personel_odeme`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `personel_odeme` WRITE;
/*!40000 ALTER TABLE `personel_odeme` DISABLE KEYS */;
INSERT INTO `personel_odeme` VALUES
(1,1,'maas',30000.00,'2026-10-01',NULL,NULL,0,NULL,'2026-10-01 12:51:51'),
(2,3,'maas',10000.00,'2026-10-01',NULL,NULL,0,NULL,'2026-10-01 22:50:25'),
(3,2,'maas',20000.00,'2026-10-01','2026/10',NULL,1,1,'2026-10-01 23:04:56'),
(4,1,'maas',5000.00,'2026-10-03',NULL,NULL,1,1,'2026-10-03 15:20:15'),
(5,3,'maas',5000.00,'2026-10-03',NULL,NULL,1,1,'2026-10-03 16:35:12'),
(6,3,'maas',5000.00,'2026-10-03',NULL,NULL,1,1,'2026-10-03 16:37:52'),
(7,1,'maas',14999.98,'2026-10-04',NULL,NULL,1,1,'2026-10-04 10:51:53'),
(8,1,'maas',0.02,'2026-10-04',NULL,NULL,1,1,'2026-10-04 10:53:20');
/*!40000 ALTER TABLE `personel_odeme` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `satis_fatura_detaylari`
--

DROP TABLE IF EXISTS `satis_fatura_detaylari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `satis_fatura_detaylari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fatura_id` int(11) NOT NULL,
  `urun_id` int(11) NOT NULL,
  `birim_fiyat` decimal(10,2) DEFAULT 0.00,
  `adet` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_satis_detay_fatura` (`fatura_id`),
  KEY `idx_satis_detay_urun` (`urun_id`),
  CONSTRAINT `fk_satis_detay_fatura` FOREIGN KEY (`fatura_id`) REFERENCES `satis_faturalar` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_satis_detay_urun` FOREIGN KEY (`urun_id`) REFERENCES `urunler` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `satis_fatura_detaylari`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `satis_fatura_detaylari` WRITE;
/*!40000 ALTER TABLE `satis_fatura_detaylari` DISABLE KEYS */;
INSERT INTO `satis_fatura_detaylari` VALUES
(3,41,12,70.00,1),
(4,42,12,70.00,1),
(5,42,16,150.00,1),
(6,43,16,150.00,1),
(7,44,16,150.00,1),
(8,44,13,150.00,1),
(9,45,17,30.00,1),
(10,46,10,150.00,1),
(11,47,15,70.00,1),
(12,48,6,30.00,1),
(13,48,7,7.00,1),
(14,49,18,50.00,1),
(15,50,11,3.00,1),
(16,50,13,150.00,1),
(17,51,21,250.00,1),
(18,51,10,150.00,1),
(19,52,11,3.00,1),
(20,53,24,300.00,1),
(21,53,20,-200.00,1),
(22,54,1,140.00,2),
(23,54,24,300.00,1),
(24,55,11,3.00,2),
(25,56,24,300.00,1),
(26,57,1,140.00,2),
(27,57,24,300.00,1),
(28,58,15,70.00,2),
(29,58,13,150.00,1),
(30,59,5,3.00,10),
(31,60,21,250.00,1),
(32,61,19,140.00,1),
(33,62,15,70.00,1),
(34,62,10,150.00,1),
(35,63,19,140.00,2),
(37,65,27,25.50,3),
(38,66,15,70.00,1);
/*!40000 ALTER TABLE `satis_fatura_detaylari` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `satis_faturalar`
--

DROP TABLE IF EXISTS `satis_faturalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `satis_faturalar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cari_id` int(11) NOT NULL,
  `tarih` date NOT NULL,
  `odenen_tutar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `durum` enum('odenmedi','kismi','odendi') NOT NULL DEFAULT 'odenmedi',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_satis_cari` (`cari_id`),
  CONSTRAINT `fk_satis_cari` FOREIGN KEY (`cari_id`) REFERENCES `cariler` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `satis_faturalar`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `satis_faturalar` WRITE;
/*!40000 ALTER TABLE `satis_faturalar` DISABLE KEYS */;
INSERT INTO `satis_faturalar` VALUES
(41,3,'2026-09-18',70.00,'odendi','2026-09-18 16:48:09'),
(42,4,'2026-09-18',220.00,'odendi','2026-09-18 17:29:06'),
(43,2,'2026-09-18',150.00,'odendi','2026-09-18 19:08:41'),
(44,3,'2026-09-19',300.00,'odendi','2026-09-18 21:27:01'),
(45,3,'2026-09-19',30.00,'odendi','2026-09-18 21:31:23'),
(46,2,'2026-09-19',150.00,'odendi','2026-09-19 10:47:03'),
(47,3,'2026-09-19',70.00,'odendi','2026-09-19 11:00:28'),
(48,2,'2026-09-19',37.00,'odendi','2026-09-19 11:59:10'),
(49,3,'2026-09-19',50.00,'odendi','2026-09-19 12:33:52'),
(50,3,'2026-09-20',153.00,'odendi','2026-09-19 22:06:46'),
(51,3,'2026-09-20',400.00,'odendi','2026-09-20 09:31:38'),
(52,5,'2026-09-20',3.00,'odendi','2026-09-20 13:06:26'),
(53,3,'2026-09-21',100.00,'odendi','2026-09-21 19:12:21'),
(54,2,'2026-09-25',580.00,'odendi','2026-09-25 11:27:42'),
(55,3,'2026-09-27',6.00,'odendi','2026-09-27 14:36:09'),
(56,1,'2026-10-01',300.00,'odendi','2026-10-01 01:19:50'),
(57,3,'2026-10-01',580.00,'odendi','2026-10-01 17:05:40'),
(58,2,'2026-10-02',290.00,'odendi','2026-10-02 17:06:35'),
(59,3,'2026-10-03',30.00,'odendi','2026-10-03 19:18:37'),
(60,5,'2026-10-03',250.00,'odendi','2026-10-03 19:31:10'),
(61,4,'2026-10-03',140.00,'odendi','2026-10-03 19:35:54'),
(62,1,'2026-10-03',220.00,'odendi','2026-10-03 21:09:23'),
(63,2,'2026-10-04',280.00,'odendi','2026-10-04 10:05:18'),
(65,2,'2026-10-05',76.50,'odendi','2026-10-05 13:01:19'),
(66,3,'2026-10-05',70.00,'odendi','2026-10-05 14:03:48');
/*!40000 ALTER TABLE `satis_faturalar` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `stok_hareketleri`
--

DROP TABLE IF EXISTS `stok_hareketleri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stok_hareketleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urun_id` int(11) NOT NULL,
  `tip` enum('giris','cikis') NOT NULL,
  `miktar` int(11) NOT NULL,
  `aciklama` varchar(255) DEFAULT NULL,
  `kaynak` enum('alis_fatura','satis_fatura','manuel','iade','sayim') NOT NULL DEFAULT 'manuel',
  `kaynak_id` int(11) DEFAULT NULL,
  `tarih` date NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_urun` (`urun_id`),
  KEY `idx_tarih` (`tarih`),
  CONSTRAINT `1` FOREIGN KEY (`urun_id`) REFERENCES `urunler` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stok_hareketleri`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `stok_hareketleri` WRITE;
/*!40000 ALTER TABLE `stok_hareketleri` DISABLE KEYS */;
INSERT INTO `stok_hareketleri` VALUES
(1,1,'giris',15,NULL,'manuel',NULL,'2026-09-25','2026-09-25 11:18:24'),
(2,1,'giris',40,'Alış faturası #1','alis_fatura',1,'2026-09-30','2026-09-30 16:43:25'),
(3,4,'giris',12,'Alış faturası #1','alis_fatura',1,'2026-09-30','2026-09-30 16:43:25'),
(4,2,'giris',30,'Alış faturası #1','alis_fatura',1,'2026-09-30','2026-09-30 16:43:25'),
(5,5,'giris',15,'Alış faturası #1','alis_fatura',1,'2026-09-30','2026-09-30 16:43:25'),
(6,13,'giris',15,NULL,'manuel',NULL,'2026-10-01','2026-10-01 00:53:05'),
(7,21,'giris',20,NULL,'manuel',NULL,'2026-10-01','2026-10-01 00:56:14'),
(8,24,'giris',20,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:00:28'),
(9,6,'giris',20,'Manuel','manuel',NULL,'2026-10-01','2026-10-01 01:07:11'),
(10,11,'giris',50,'Manuel','manuel',NULL,'2026-10-01','2026-10-01 01:16:10'),
(11,11,'giris',50,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:16:42'),
(12,11,'giris',50,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:18:03'),
(13,15,'giris',5,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:18:27'),
(14,15,'giris',15,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:18:54'),
(15,24,'cikis',1,'Satış faturası #56','satis_fatura',56,'2026-10-01','2026-10-01 01:19:50'),
(16,10,'giris',5,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:33:44'),
(17,10,'giris',10,NULL,'manuel',NULL,'2026-10-01','2026-10-01 01:34:02'),
(18,20,'giris',25,NULL,'manuel',NULL,'2026-10-01','2026-10-01 17:01:12'),
(19,19,'giris',28,NULL,'manuel',NULL,'2026-10-01','2026-10-01 17:01:29'),
(20,7,'giris',30,NULL,'manuel',NULL,'2026-10-01','2026-10-01 17:01:54'),
(21,1,'cikis',2,'Satış faturası #57','satis_fatura',57,'2026-10-01','2026-10-01 17:05:40'),
(22,24,'cikis',1,'Satış faturası #57','satis_fatura',57,'2026-10-01','2026-10-01 17:05:40'),
(23,18,'giris',25,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:45:47'),
(24,23,'giris',25,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:46:05'),
(25,22,'giris',25,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:46:23'),
(26,16,'giris',20,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:46:39'),
(27,25,'giris',20,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:46:57'),
(28,12,'giris',20,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:47:12'),
(29,17,'giris',21,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:47:24'),
(30,8,'giris',30,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:47:42'),
(31,9,'giris',50,NULL,'manuel',NULL,'2026-10-02','2026-10-02 02:47:57'),
(32,15,'cikis',2,'Satış faturası #58','satis_fatura',58,'2026-10-02','2026-10-02 17:06:35'),
(33,13,'cikis',1,'Satış faturası #58','satis_fatura',58,'2026-10-02','2026-10-02 17:06:35'),
(34,5,'cikis',10,'Satış faturası #59','satis_fatura',59,'2026-10-03','2026-10-03 19:18:37'),
(35,15,'giris',1,'Alış faturası #2','alis_fatura',2,'2026-10-03','2026-10-03 19:20:57'),
(36,21,'cikis',1,'Satış faturası #60','satis_fatura',60,'2026-10-03','2026-10-03 19:31:10'),
(37,19,'cikis',1,'Satış faturası #61','satis_fatura',61,'2026-10-03','2026-10-03 19:35:54'),
(38,15,'cikis',1,'Satış faturası #62','satis_fatura',62,'2026-10-03','2026-10-03 21:09:23'),
(39,10,'cikis',1,'Satış faturası #62','satis_fatura',62,'2026-10-03','2026-10-03 21:09:23'),
(40,5,'giris',10,NULL,'manuel',NULL,'2026-10-04','2026-10-03 22:09:59'),
(41,19,'cikis',2,'Satış faturası #63','satis_fatura',63,'2026-10-04','2026-10-04 10:05:18'),
(43,27,'giris',15,NULL,'manuel',NULL,'2026-10-05','2026-10-05 12:59:58'),
(44,26,'giris',20,NULL,'manuel',NULL,'2026-10-05','2026-10-05 13:00:09'),
(45,27,'cikis',3,'Satış faturası #65','satis_fatura',65,'2026-10-05','2026-10-05 13:01:19'),
(46,15,'cikis',1,'Satış faturası #66','satis_fatura',66,'2026-10-05','2026-10-05 14:03:48');
/*!40000 ALTER TABLE `stok_hareketleri` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tedarikciler_old`
--

DROP TABLE IF EXISTS `tedarikciler_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tedarikciler_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unvan` varchar(255) NOT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tedarikciler_old`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tedarikciler_old` WRITE;
/*!40000 ALTER TABLE `tedarikciler_old` DISABLE KEYS */;
INSERT INTO `tedarikciler_old` VALUES
(1,'Ergaz San.Ltd.Şti.','0 555 580 6677','Kemalpaşa V.D Ulucak beldesi.Kemalpaşa/İzmir','2026-09-27 16:44:38');
/*!40000 ALTER TABLE `tedarikciler_old` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `urunler`
--

DROP TABLE IF EXISTS `urunler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `urunler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urun_adi` varchar(255) NOT NULL,
  `kritik_seviye` int(11) DEFAULT 10,
  `varsayilan_alis_fiyati` decimal(10,2) DEFAULT 0.00,
  `varsayilan_satis_fiyati` decimal(10,2) DEFAULT 0.00,
  `durum` tinyint(1) DEFAULT 1,
  `stok` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_urun_adi` (`urun_adi`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urunler`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `urunler` WRITE;
/*!40000 ALTER TABLE `urunler` DISABLE KEYS */;
INSERT INTO `urunler` VALUES
(1,'12kg Mutfak Tüp',10,200.00,300.00,1,51,'2026-09-02 19:30:43'),
(2,'2kg Piknik Tüp',10,10.00,15.00,1,30,'2026-09-02 19:38:05'),
(4,'24kg Ticari Tüp',10,200.00,300.00,1,12,'2026-09-02 19:52:36'),
(5,'45kg Sanayi Tüp',10,500.00,700.00,1,15,'2026-09-02 22:17:54'),
(6,'Kaynak Su Damacana',10,20.00,30.00,1,20,'2026-09-03 13:55:22'),
(7,'Piknik Süzgeç',10,5.00,10.00,1,30,'2026-09-03 14:36:30'),
(8,'suzgec',10,5.00,7.00,1,30,'2026-09-03 14:40:49'),
(9,'Tüp Hortumu',10,10.00,13.00,1,50,'2026-09-03 14:53:28'),
(10,'ocak',10,100.00,150.00,1,15,'2026-09-03 15:00:27'),
(11,'Kelepçe',10,2.00,3.00,1,150,'2026-09-03 15:17:15'),
(12,'Soba',10,50.00,70.00,1,20,'2026-09-03 15:22:20'),
(13,'Davul Fırın',10,100.00,150.00,1,14,'2026-09-03 15:26:35'),
(15,'Mini Fırın',10,50.00,70.00,1,18,'2026-09-03 16:45:01'),
(16,'Sanayi Dedantör',10,100.00,150.00,1,20,'2026-09-03 16:50:39'),
(17,'Soba Başlığı',10,20.00,30.00,1,21,'2026-09-03 17:03:38'),
(18,'Pürmüz',10,30.00,50.00,1,25,NULL),
(19,'Ocak Tekli ',10,100.00,140.00,1,25,NULL),
(20,'Ocak İkili ',10,150.00,200.00,1,25,NULL),
(21,'Gaz Lambası',10,150.00,250.00,1,19,NULL),
(22,'Pürmüz Küçük',10,100.00,120.00,1,25,NULL),
(23,'Pürmüz Büyük',10,200.00,240.00,1,25,NULL),
(24,'Gaz Lambası Büyük ',10,200.00,300.00,1,18,NULL),
(25,'Set Üstü Ocak',10,500.00,700.00,1,20,NULL),
(26,'Ocak Doğalgaz',5,500.00,750.00,1,20,NULL),
(27,'Piknik Ocak Üstü',10,20.00,25.50,1,12,NULL);
/*!40000 ALTER TABLE `urunler` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Final view structure for view `kasa_bakiye_view`
--

/*!50001 DROP VIEW IF EXISTS `kasa_bakiye_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`kadri`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kasa_bakiye_view` AS select `k`.`id` AS `id`,`k`.`ad` AS `ad`,`k`.`tip` AS `tip`,`k`.`banka_adi` AS `banka_adi`,`k`.`iban` AS `iban`,`k`.`acilis_bakiye` AS `acilis_bakiye`,`k`.`aktif` AS `aktif`,`k`.`created_at` AS `created_at`,`k`.`acilis_bakiye` + coalesce((select sum(case when `kasa_hareketleri`.`tip` = 'giris' then `kasa_hareketleri`.`tutar` else -`kasa_hareketleri`.`tutar` end) from `kasa_hareketleri` where `kasa_hareketleri`.`kasa_id` = `k`.`id`),0) - coalesce((select sum(`personel_odeme`.`tutar`) from `personel_odeme` where `personel_odeme`.`kasa_id` = `k`.`id` and `personel_odeme`.`kasadan_dus` = 1),0) + coalesce((select sum(case when `fatura_odemeleri`.`fatura_tipi` = 'satis' then `fatura_odemeleri`.`tutar` else -`fatura_odemeleri`.`tutar` end) from `fatura_odemeleri` where `fatura_odemeleri`.`kasa_id` = `k`.`id` and `fatura_odemeleri`.`kasadan_dus` = 1),0) AS `bakiye` from `kasa_hesaplari` `k` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-06 14:40:20
